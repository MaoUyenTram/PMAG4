﻿using PMAG4.Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PMAG4
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ExercisesPage : ContentPage
	{
        public Exercise Exercise { get; set; }
        public List<string> StepTitles { get; set; }
        public int StepCounter { get; set; }
        public event EventHandler ExerciseSucceeded;
        public event EventHandler ExerciseFailed;
        public ExercisesPage(Exercise Exercise)
        {
            InitializeComponent();

            StepCounter = 0;
            this.Exercise = Exercise;
            Header.Text = Exercise.Title;
            StepTitles = new List<string>();
            for (int i = 0; i < Exercise.Steps.Count; i++)
            {
                StepTitles.Add("Stap " + (i+1));
            }
            StepInformationLabel.Text = StepTitles[StepCounter] + ": " + Exercise.Steps[StepCounter].Question + "\n\n" + Exercise.Steps[StepCounter].StepType;
            StepList.ItemsSource = StepTitles;
            StepList.SelectedItem = ((List<string>)StepList.ItemsSource).FirstOrDefault();
        }

        async void OnStepButtonClicked(object sender, EventArgs e)
        {
            
            switch (Exercise.Steps[StepCounter].StepType)
            {

                case Step.Types.Startex:
                    var MaterialPage = new MaterialPage((MaterialStep)Exercise.Steps[StepCounter], Exercise.Attempts);
                    MaterialPage.StepSucceeded += HandleStepSucceeded;
                    MaterialPage.StepFailed += HandleStepFailed;
                    await Navigation.PushAsync(MaterialPage);
                    break;
                case Step.Types.Question:
                    var QuestionPage = new QuestionPage((QuestionStep)Exercise.Steps[StepCounter], Exercise. Attempts);
                    QuestionPage.StepSucceeded += HandleStepSucceeded;
                    QuestionPage.StepFailed += HandleStepFailed;
                    await Navigation.PushAsync(QuestionPage);
                    break;
                case Step.Types.Method:
                    var MethodPage = new MethodPage((MethodStep)Exercise.Steps[StepCounter], Exercise.Attempts);
                    MethodPage.StepSucceeded += HandleStepSucceeded;
                    MethodPage.StepFailed += HandleStepFailed;
                    await Navigation.PushAsync(MethodPage);
                    break;
                case Step.Types.Material:
                    var StartexPage = new StartexPage((MaterialStep)Exercise.Steps[StepCounter], Exercise.Attempts);
                    StartexPage.StepSucceeded += HandleStepSucceeded;
                    StartexPage.StepFailed += HandleStepFailed;
                    await Navigation.PushAsync(StartexPage);
                    break;
                default:
                    break;
            }
        }

        private void HandleStepFailed(object sender, EventArgs e)
        {
            OnExerciseFailed();
        }

        private void HandleStepSucceeded(object sender, EventArgs e)
        {
            StepCounter++;
            if (StepCounter >= Exercise.Steps.Count)
            {
                OnExerciseSucceeded();
                Navigation.PopAsync();
            }
            else
            {
                StepInformationLabel.Text = Exercise.Steps[StepCounter].Question + "\n\n" + Exercise.Steps[StepCounter].StepType;
                StepList.SelectedItem = ((List<string>)StepList.ItemsSource)[StepCounter];
            }
        }

        private void OnExerciseSucceeded()
        {
            ExerciseSucceeded?.Invoke(this, EventArgs.Empty);
        }

        private void OnExerciseFailed()
        {
            ExerciseFailed?.Invoke(this, EventArgs.Empty);
        }
    }
}