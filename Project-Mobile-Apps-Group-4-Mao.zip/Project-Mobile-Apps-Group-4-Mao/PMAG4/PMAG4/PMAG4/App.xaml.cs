﻿using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Xamarin.Forms;

namespace PMAG4
{
	public partial class App : Application
	{
        public static PublicClientApplication ClientApplication { get; set; }
        public static string[] Scopes = { "User.Read" };
        public static string UserID { get; set; }
		public App ()
		{
            //InitializeComponent();
            UserID = "";

            ClientApplication = new PublicClientApplication("8149207c-ae08-43e9-8b87-e969e350e644");
            var content = new Login();
            MainPage = new NavigationPage(content);
        }

		protected override void OnStart ()
		{
            // Handle when your app starts
            //AppCenter.Start("android=e3529a71-d2ff-4870-b256-a9f576472442;" + "uwp=766b83cd-b8c3-4010-b112-0eca477429d0;" + "ios=2af8d9a4-c1a5-45c4-b264-61e724758a96;", typeof(Analytics), typeof(Crashes));
        }

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}
	}
    //Cheat sheet (Wissam) ^^
    /*
    Application.Current.Properties["username"] = ... Voor het opslagen van username voor sessie na inloggen

    Page = screen type <- View is onderdeel hiervan
    soorten pages : NavigationPage / ContentPage / MasterDetailPage / TabbedPage / CarouselPage
    "Layout in Xamarin.Forms" googelen voor layout opties

     Device.OnPlatform                           - Voor device specifieke code te runnen
     (
        iOS: () => {},
        Android: () => {},
        Windows: () => {},
        Default: () => {}
     );

    Device.OnPlatform(<T>(iOS),<T>(Andr), <T>(Win)) -waar T vervangen kan worden door eender welk type var
                                                     voor OS specifieke delegate methods of cijfers
                                                     bvb: Layout parameters die per OS anders zijn

    Device.Idiom == TargetIdiom."Tablet/..."        -voor device specifieke code
    Device.OS == TargetPlatform."iOS/..."           -voor OS specifieke code
    */
}
