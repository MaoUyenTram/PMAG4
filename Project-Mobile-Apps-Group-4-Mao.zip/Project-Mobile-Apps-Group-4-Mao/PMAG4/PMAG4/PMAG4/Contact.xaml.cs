﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace PMAG4
{
    public partial class Contact : ContentPage
    {
        public Contact()
        {
            InitializeComponent();
        }


    }
}
