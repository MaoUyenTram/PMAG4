﻿using PMAG4.Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PMAG4
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MethodPage : ContentPage
	{
        public MethodStep Step { get; set; }
        public ObservableCollection<string> Options { get; set; }
        public ObservableCollection<string> Methods { get; set; }
        public int Attempt { get; set; }

        public event EventHandler StepSucceeded;

        public event EventHandler StepFailed;

        private void OnStepSucceeded()
        {
            if (StepSucceeded != null)
            {
                StepSucceeded(this, EventArgs.Empty);
            }
        }

        private void OnStepFailed()
        {
            if (StepFailed != null)
            {
                StepFailed(this, EventArgs.Empty);
            }
        }

        public MethodPage (MethodStep Step, int Attempt)
		{
			InitializeComponent ();
            this.Attempt = Attempt;
            this.Step = Step;
            Methods = new ObservableCollection<string>();
            Options = new ObservableCollection<string>(Step.Methods);
            Options.Shuffle();
            OptionList.ItemsSource = Options;
            MethodList.ItemsSource = Methods;
		}
        async void OnOptionTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            Methods.Add((string)e.Item);
            Options.Remove((string)e.Item);
            if(Options.Count == 0)
            {
                if (CheckSolution(Methods))
                {
                    OnStepSucceeded();
                    await Navigation.PopAsync();
                } else
                {
                    if (Attempt == 3)
                    {
                        await DisplayAlert("Feedback", Step.Feedback, "Ok");
                    }
                    else if (Attempt == 5)
                    {
                        OnStepFailed();
                        await Navigation.PopAsync();
                    }
                    Attempt++;
                    AttemptLabel.Text = "Poging: " + Attempt.ToString();
                }
            }
        }

        public void OnMethodTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            Options.Add((string)e.Item);
            Methods.Remove((string)e.Item);
        }

        private bool CheckSolution(ObservableCollection<string> collection)
        {
            ObservableCollection<string> temp = new ObservableCollection<string>(Step.Methods);
            for(int i = 0; i < temp.Count; i++)
            {
                if(temp[i] != collection[i])
                {
                    return false;
                }
            }
            return true;
        }
    }

    static class Extensions
    {
        private static Random RNG = new Random();
        public static void Shuffle<T>(this IList<T> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = RNG.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}