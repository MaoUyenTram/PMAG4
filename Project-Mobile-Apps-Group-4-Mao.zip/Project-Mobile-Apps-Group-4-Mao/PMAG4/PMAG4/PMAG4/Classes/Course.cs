﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4.Classes
{
    public class Course
    {
        public string ID { get; set; }
        public string Title { get; set; }
        public List<Exercise> Exercises { get; set; }
        public DateTime LastBanned { get; set; }

        public Course(string ID, string Title)
        {
            this.ID = ID;
            this.Title = Title;
            Exercises = new List<Exercise>();
        }

        public Course(string ID, string Title, List<Exercise> Exercises)
        {
            this.ID = ID;
            this.Title = Title;
            this.Exercises = Exercises;
        }

        public Course(string ID, string Title, DateTime LastBanned)
        {
            this.ID = ID;
            this.Title = Title;
            this.LastBanned = LastBanned;
        }

        public override string ToString()
        {
            return Title;
        }
    }
}
