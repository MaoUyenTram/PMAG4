﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4.Classes
{
    public class MethodStep : Step
    {
        public List<string> Methods { get; set; }
        public MethodStep(string ID, string Question, List<string> Methods, string Feedback) : base(ID, Types.Method, Question, Feedback)
        {
            this.Methods = Methods;
        }
    }
}
