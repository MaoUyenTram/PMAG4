﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace PMAG4.Classes
{
    public abstract class API
    {
        private static string APILink = "http://dtsl.ehb.be/~ief.falot/PMA/api/v1.1/public/index.php";

        public static string Login(string Usermail, string Password)
        {
            string result = null;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(APILink + "/user/login");
            request.ContentType = "application/json";
            request.Method = "POST";
            request.Accept = "application/json";

            using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                dynamic json = new JObject();
                json.userEmail = Usermail;
                json.userPass = SHA256(Password);
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)request.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();
            }

            if (result.All(char.IsDigit))
            {
                return App.UserID = result;
            }
            else
            {
                App.UserID = null;
                return result;
            }
        }

        public static List<Course> GetCoursesById(string UserId)
        {
            List<Course> courses = new List<Course>();
            JArray JArrayCourses = JArray.Parse(APICall(APILink + "/coursesByIdUser/" + UserId));

            foreach(JObject JCourse in JArrayCourses)
            {
                Course course = new Course(JCourse.GetValue("idCourse").ToString(), JCourse.GetValue("course_name").ToString(), DateTime.Parse(JCourse.GetValue("timestampSinceLastBan").ToString()));

                courses.Add(course);
            }
            return courses;
        }

        public static List<Exercise> GetExercisesByCourseId(string CourseId)
        {
            List<Exercise> exercises = new List<Exercise>();
            try
            {
                JArray JArrayCourses = JArray.Parse(APICall(APILink + "/exercisesByIdCourse/" + CourseId));

                foreach (JObject JCourse in JArrayCourses)
                {
                    //string ID, string Title, DateTime Created, DateTime Modified, DateTime Deadline
                    Exercise exercise = new Exercise(JCourse.GetValue("idExercise").ToString(), JCourse.GetValue("exercise_name").ToString(), JCourse.GetValue("exercise_description").ToString(), Int32.Parse(JCourse.GetValue("attempts").ToString()), DateTime.Parse(JCourse.GetValue("timestampCreated").ToString()), DateTime.Parse(JCourse.GetValue("timestampLastUpdated").ToString()), DateTime.Parse(JCourse.GetValue("exercise_deadline").ToString()));
                    exercises.Add(exercise);
                }
            }catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return exercises;
        }

        public static List<Step> GetStepsByExerciseId(string ExerciseId)
        {
            Dictionary<string, Step> steps = new Dictionary<string, Step>();
            try
            {
                JArray JArrayCourses = JArray.Parse(APICall(APILink + "/stepsByIdExercise/" + ExerciseId));
                
                foreach (JObject JCourse in JArrayCourses)
                {
                    if (steps.ContainsKey(JCourse.GetValue("idStep").ToString()))
                    {
                        switch (JCourse.GetValue("stepType").ToString())
                        {
                            case "Material":
                                MaterialStep currentMaterialStep = (MaterialStep)steps[JCourse.GetValue("idStep").ToString()];
                                currentMaterialStep.Materials.Add(GetMaterialById(JCourse.GetValue("Material_idMaterial").ToString()));
                                break;
                            case "Question":
                                break;
                            case "Method":
                                MethodStep currentMethodStep = (MethodStep)steps[JCourse.GetValue("idStep").ToString()];
                                currentMethodStep.Methods.Add(GetMethodById(JCourse.GetValue("Method_idMethod").ToString()));
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        //string ID, string Title, DateTime Created, DateTime Modified, DateTime Deadline
                        switch (JCourse.GetValue("stepType").ToString())
                        {
                            case "Material":
                                List<Material> materials = new List<Material>();
                                materials.Add(GetMaterialById(JCourse.GetValue("Material_idMaterial").ToString()));
                                steps.Add(JCourse.GetValue("idStep").ToString(), new MaterialStep(JCourse.GetValue("idStep").ToString(), JCourse.GetValue("question").ToString(), materials, JCourse.GetValue("feedback").ToString()));
                                break;
                            case "Question":
                                steps.Add(JCourse.GetValue("idStep").ToString(), new QuestionStep(JCourse.GetValue("idStep").ToString(), JCourse.GetValue("question").ToString(), JCourse.GetValue("answer").ToString(), JCourse.GetValue("feedback").ToString()));
                                break;
                            case "Method":
                                List<string> methods = new List<string>();
                                methods.Add(GetMethodById(JCourse.GetValue("Method_idMethod").ToString()));
                                steps.Add(JCourse.GetValue("idStep").ToString(), new MethodStep(JCourse.GetValue("idStep").ToString(), JCourse.GetValue("question").ToString(), methods, JCourse.GetValue("feedback").ToString()));
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            List<Step> outputSteps = steps.Values.ToList();
            return outputSteps;
        }
        public static ObservableCollection<Material> GetAllMaterial()
        {
            ObservableCollection<Material> materials = new ObservableCollection<Material>();
            try
            {
                JArray JArrayCourses = JArray.Parse(APICall(APILink + "/material/getall"));

                foreach (JObject JCourse in JArrayCourses)
                {
                    //string ID, string Name, string Description, string Image, GlassType Type
                    //if (JCourse.GetValue("material_qualitative").ToString() == "0")

                    Material material = new Material(JCourse.GetValue("idMaterial").ToString(), JCourse.GetValue("material_name").ToString(), JCourse.GetValue("material_description").ToString(), JCourse.GetValue("material_image").ToString(), Material.GlassType.Quantity);
                    materials.Add(material);
                    //else
                        //material = new Material(MaterialId, JCourse.GetValue("material_name").ToString(), JCourse.GetValue("material_description").ToString(), JCourse.GetValue("material_image").ToString(), Material.GlassType.Quality);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return materials;
        }
        public static Material GetMaterialById(string MaterialId)
        {
            Material material = null;
            try
            {
                JArray JArrayCourses = JArray.Parse(APICall(APILink + "/material/" + MaterialId));

                foreach (JObject JCourse in JArrayCourses)
                {
                    //string ID, string Name, string Description, string Image, GlassType Type
                    if (JCourse.GetValue("material_qualitative").ToString() == "0")
                        material = new Material(MaterialId, JCourse.GetValue("material_name").ToString(), JCourse.GetValue("material_description").ToString(), JCourse.GetValue("material_image").ToString(), Material.GlassType.Quantity);
                    else
                        material = new Material(MaterialId, JCourse.GetValue("material_name").ToString(), JCourse.GetValue("material_description").ToString(), JCourse.GetValue("material_image").ToString(), Material.GlassType.Quality);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return material;
        }

        public static string GetMethodById(string MethodId)
        {
            string method = null;
            try
            {
                JArray JArrayCourses = JArray.Parse(APICall(APILink + "/method/" + MethodId));

                foreach (JObject JCourse in JArrayCourses)
                {
                    method = JCourse.GetValue("text").ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return method;
        }

        public static void SetExerciseCompleted(string UserId, string ExerciseId)
        {
            try
            {
                Console.WriteLine(APICall(APILink + " / setExercisePassed / " + UserId + " / " + ExerciseId));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SetExerciseFailed(string UserId, string ExerciseId, int Attempts)
        {
            try
            {
                Console.WriteLine(APICall(APILink + " / setExerciseFailed / " + UserId + " / " + ExerciseId + "/" + Attempts));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static string APICall(string APILink)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(APILink);
            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            StreamReader sr = new StreamReader(response.GetResponseStream());

            return sr.ReadToEnd();
        }

        private static string SHA256(string randomString)
        {
            var crypt = new SHA256Managed();
            string hash = String.Empty;
            byte[] crypto = crypt.ComputeHash(Encoding.ASCII.GetBytes(randomString));
            foreach (byte theByte in crypto)
            {
                hash += theByte.ToString("x2");
            }
            return hash;
        }
    }
}
