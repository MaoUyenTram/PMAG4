﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4.Classes
{
    public class Step
    {
        public enum Types { Material, Question, Method, Startex }

        public string ID { get; set; }
        public Types StepType { get; set; }
        public string Question { get; set; }
        public string Feedback { get; set; }
        internal Step(string ID, Types StepType, string Question, string Feedback)
        {
            this.ID = ID;
            this.StepType = StepType;
            this.Question = Question;
            this.Feedback = Feedback;
        }
    }
}
