﻿using PMAG4.Classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4
{
    public class Exercise
    {
        public string ID { get; set; }
        public string Title { get; set; }
        public List<Step> Steps { get; set; }
        public string Description { get; set; }
        public int Attempts { get; set; }
        public DateTime Created { get; }
        public DateTime Modified { get; set; }
        public DateTime Deadline { get; set; }


        public Exercise(string ID, string Title, DateTime Created, DateTime Deadline)
        {
            Steps = new List<Step>();
            this.ID = ID;
            this.Title = Title;
            this.Created = Created;
            this.Deadline = Deadline;
            this.Modified = Created;
            Steps = new List<Step>();
            //TODO: Het ophalen van de Exercise vanuit de database en de array opvullen met de correcte stappen.
        }

        public Exercise(string ID, string Title, string Description, int Attempt, DateTime Created, DateTime Modified, DateTime Deadline) : this(ID, Title, Created, Deadline)
        {
            Steps = new List<Step>();
            this.ID = ID;
            this.Title = Title;
            this.Created = Created;
            this.Deadline = Deadline;
            this.Modified = Created;
            Steps = new List<Step>();
            this.Attempts = Attempt;
        }

        public Exercise(string ID, string Title, string Description, DateTime Created, DateTime Modified, DateTime Deadline) : this(ID, Title, Created, Deadline)
        {
            this.Description = Description;
            this.Modified = Modified;
            Steps = new List<Step>();
            //TODO: Het ophalen van de Exercise vanuit de database en de array opvullen met de correcte stappen.

        }

        public override string ToString()
        {
            return Title;
        }
        // TODO: Verder uitbouwen van de code voor oefeningen
    }
}
