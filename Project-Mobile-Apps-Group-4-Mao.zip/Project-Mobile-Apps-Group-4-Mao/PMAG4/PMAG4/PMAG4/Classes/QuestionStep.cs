﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4.Classes
{
    public class QuestionStep : Step
    {
        public string Answer { get; set; }
        public QuestionStep(string ID, string Question, string Answer, string Feedback) : base(ID, Types.Question, Question, Feedback)
        {
            this.Answer = Answer;
        }
    }
}
