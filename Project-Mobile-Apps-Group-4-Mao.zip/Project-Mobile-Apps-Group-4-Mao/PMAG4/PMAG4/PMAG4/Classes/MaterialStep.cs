﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4.Classes
{
    public class MaterialStep : Step
    {
        public List<Material> Materials { get; set; }
        public MaterialStep(string ID, string Question, List<Material> Materials, string Feedback) : base(ID, Types.Material, Question, Feedback)
        {
            this.Materials = Materials;
        }
    }
}
