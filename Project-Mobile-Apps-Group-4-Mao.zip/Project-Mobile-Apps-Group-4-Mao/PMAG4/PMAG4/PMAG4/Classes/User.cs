﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4
{
    public class User
    {
        public string Username { get; set; }
        public string Email { get; set; }
        //Email wordt gebruikt als username voor de user in te loggen voornamelijk
        public string Password { get; set; }
        public string Naam { get; set; }
    }

    //Add SHA256
}
