﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMAG4
{
    public class Material
    {
        public enum GlassType { Quantity, Quality }
        public string ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public DateTime Added { get; set; }
        public GlassType Type { get; set; }

        public Material(string ID, string Name, string Description, string Image, GlassType Type)
        {
            this.ID = ID;
            this.Name = Name;
            this.Description = Description;
            this.Type = Type;
            this.Added = DateTime.Now ;
        }

        public override string ToString()
        {
            return this.Name;
        }
    }
}
