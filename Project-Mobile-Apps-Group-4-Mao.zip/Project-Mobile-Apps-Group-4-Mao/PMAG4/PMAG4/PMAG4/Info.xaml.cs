﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace PMAG4
{
    public partial class Info : ContentPage
    {
        public Info()
        {
            InitializeComponent();
            InfoLabel.Text = "Project Mobile Apps 2018\n\nTom Vanlaer\nCyril Delander\nIef Falot\nWissam Nasser\nMao Uyen\n\nCreated with Xamarin";
        }
    }
}
