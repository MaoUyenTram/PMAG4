﻿using PMAG4.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace PMAG4
{
    public partial class Dashboard : ContentPage
    {
        private Course SelectedCourse;
        private Exercise SelectedExercise;
        public Dashboard(string UserID)
        {
            InitializeComponent();
            if(UserID.Equals("") || UserID == null)
            {
                Navigation.PopAsync();
            }
            this.BindingContext = new List<string>();
            WelcomePlaceholder.Text = "Welcome " + UserID; //+ App.user.Naam;
        }

        protected override void OnAppearing()
        {
            List<Course> courses = GetCourses();
            CoursesList.ItemsSource = courses;
        }

        private List<Course> GetCourses()
        {
            //List<Exercise> exercises;
            //Random r = new Random(Seed: DateTime.Now.Millisecond);
            //TODO: For loop vervangen door data uit database
            /*List<Exercise> testExercises = new List<Exercise>();
            testExercises.Add(new Exercise("00013", "Test Exercise", DateTime.Now, DateTime.Now.AddYears(1)));
            List<Step> testSteps = new List<Step>();

            List<string> MethodsList = new List<string>();
            List<Material> MaterialList = new List<Material>();

            MethodsList.Add("Method 1");
            MethodsList.Add("Method 2");
            MethodsList.Add("Method 3");
            MethodsList.Add("Method 4");
            MethodsList.Add("Method 5");
            MethodsList.Add("Method 6");
            MethodsList.Add("Method 7");
            MethodsList.Add("Method 8");
            MethodsList.Add("Method 9");
            MethodsList.Add("Method 10");
            MethodsList.Add("Method 11");
            MethodsList.Add("Method 12");
            MethodsList.Add("Method 13");
            MethodsList.Add("Method 14");

            MaterialList.Add(new Material("Mat001", "Materiaal 001", "Test Materiaal", Material.GlassType.Quality));
            MaterialList.Add(new Material("Mat002", "Materiaal 002", "Test Materiaal", Material.GlassType.Quantity));
            MaterialList.Add(new Material("Mat003", "Materiaal 003", "Test Materiaal", Material.GlassType.Quality));
            MaterialList.Add(new Material("Mat004", "Materiaal 004", "Test Materiaal", Material.GlassType.Quantity));
            MaterialList.Add(new Material("Mat005", "Materiaal 005", "Test Materiaal", Material.GlassType.Quality));
            MaterialList.Add(new Material("Mat006", "Materiaal 006", "Test Materiaal", Material.GlassType.Quantity));
            
            testSteps.Add(new MaterialStep("0001", "A question about Materials", MaterialList, "MaterialFeedback"));
            testSteps.Add(new MethodStep("0002", "A question about Methods", MethodsList, "MethodFeedback"));
            testSteps.Add(new QuestionStep("0003", "A question", "An Answer", "QuestionFeedback"));
            testExercises[0].Steps = testSteps;
            courses.Add(new Course("Test Course", testExercises));
            for (int i = 0; i < 14; i++)
            {
                exercises = new List<Exercise>();
                for (int j = 1; j < (r.Next() + 2) % 10; j++)
                {
                    exercises.Add(new Exercise((i + j + 1).ToString(), "Exercise " + (j), DateTime.Now, DateTime.Now.AddMonths(j).AddDays(i)));
                }
                courses.Add(new Course("Course " + (i + 1), exercises));
            }*/

            return API.GetCoursesById("2");
        }

        public void OnCourseTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            SelectedCourse = (Course)e.Item;
            if (SelectedCourse.LastBanned.AddHours(1) > DateTime.Now)
            {
                DisplayAlert("Geblokkeerd", "Wegens te veel fout antwoorden is de course gebannen tot " + SelectedCourse.LastBanned.AddHours(1), "Ok");
                SelectedCourse = null;
                ((ListView)sender).SelectedItem = null;
            }
            else
            {
                if (SelectedCourse.Exercises == null || SelectedCourse.Exercises.Count == 0)
                {
                    SelectedCourse.Exercises = API.GetExercisesByCourseId(SelectedCourse.ID);
                }
                ExerciseList.ItemsSource = SelectedCourse.Exercises;
                ExtraInfoLabel.Text = ("Course: " + SelectedCourse.ID + "\n \n");
            }
        }

        public void OnExerciseTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            SelectedExercise = (Exercise)e.Item;
            if (SelectedExercise.Steps.Count == 0)
            {
                SelectedExercise.Steps = API.GetStepsByExerciseId(SelectedExercise.ID);
            }
            ExtraInfoLabel.Text = ("Course: " + SelectedCourse.ID + "\n \n");
            ExtraInfoLabel.Text += ("Tapped: " + SelectedExercise.ID + "\n \n");
            ExtraInfoLabel.Text += ("Title: " + SelectedExercise.Title + "\n \n");
            ExtraInfoLabel.Text += ("Description: " + SelectedExercise.Description + "\n \n");
            ExtraInfoLabel.Text += ("Aantal stappen:" + SelectedExercise.Steps.Count + "\n \n");
            ExtraInfoLabel.Text += ("Pogingen: " + SelectedExercise.Attempts + "\n \n");
            ExtraInfoLabel.Text += ("Created: " + SelectedExercise.Created + "\n \n");
            ExtraInfoLabel.Text += ("Last Modified: " + SelectedExercise.Modified + "\n \n");
            ExtraInfoLabel.Text += ("Deadline: " + SelectedExercise.Deadline);
        }

        async void OnExerciseButtonClicked(object sender, EventArgs e)
        {
            if (e == null) return;
            if (SelectedExercise == null) return;
            var ExercisePage = new ExercisesPage(SelectedExercise);
            ExercisePage.ExerciseSucceeded += HandleExerciseSucceeded;
            ExercisePage.ExerciseFailed += HandleExerciseFailed;
            await Navigation.PushAsync(new ExercisesPage(SelectedExercise));
        }

        private void HandleExerciseFailed(object sender, EventArgs e)
        {
            //Code to lock user out of app for an hour
            API.SetExerciseFailed(App.UserID, SelectedExercise.ID, SelectedExercise.Attempts);
        }

        private void HandleExerciseSucceeded(object sender, EventArgs e)
        {
            //Code die database laat weten dat user door is op exercise
            API.SetExerciseCompleted(App.UserID, SelectedExercise.ID);
        }
    }
}
