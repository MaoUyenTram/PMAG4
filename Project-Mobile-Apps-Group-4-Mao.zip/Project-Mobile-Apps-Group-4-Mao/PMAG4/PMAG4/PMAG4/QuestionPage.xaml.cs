﻿using PMAG4.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PMAG4
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class QuestionPage : ContentPage
	{
        public int Attempt { get; set; }
        public QuestionStep Step { get; set; }

        public event EventHandler StepSucceeded;

        public event EventHandler StepFailed;

        private void OnStepSucceeded()
        {
            StepSucceeded?.Invoke(this, EventArgs.Empty);
        }

        private void OnStepFailed()
        {
            StepFailed?.Invoke(this, EventArgs.Empty);
        }
        public QuestionPage (QuestionStep Step, int Attempt)
		{
			InitializeComponent ();
            QuestionLabel.Text = Step.Question;
            this.Step = Step;
            this.Attempt = Attempt;
            AttemptLabel.Text = "Poging: " + Attempt.ToString();
        }

        async void OnSendClicked(object sender, EventArgs e)
        {
            if (AnswerEntry.Text != null && AnswerEntry.Text.ToLower() == Step.Answer.ToLower())
            {
                OnStepSucceeded();
                await Navigation.PopAsync();
            }
            else {
                if (Attempt == 3)
                {
                    await DisplayAlert("Feedback", Step.Feedback, "Ok");
                } else if (Attempt == 5)
                {
                    OnStepFailed();
                    await Navigation.PopAsync();
                }
                Attempt++;
                AttemptLabel.Text = "Poging: " + Attempt.ToString();
            }
        }
    }
}