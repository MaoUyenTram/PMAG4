﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Reflection.Emit;
//using Newtonsoft.Json.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
//using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json.Linq;
using System.Reflection;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using PMAG4.Classes;

namespace PMAG4
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Login : ContentPage
    {
        public Login()
        {
            InitializeComponent();
        }

        async void OnLoginClicked(object sender, EventArgs e)
        {
            try
            {
                string loginResult = API.Login(UsermailEntry.Text, PasswordEntry.Text);
                if (App.UserID != null)
                {
                    Application.Current.MainPage = new MainPage();
                } else
                {
                    await DisplayAlert("Warning:", loginResult, "Ok");
                }
            } catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        protected override void OnAppearing()
        {
            //App.ClientApplication.PlatformParameters = App.ClientApplication.PlatformParameters;
            base.OnAppearing();
        }
    }
}