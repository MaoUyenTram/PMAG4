﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PMAG4
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : TabbedPage
    {
        public MainPage ()
        {
            InitializeComponent();
            var InfoPage = new Info();
            var ContactPage = new Contact();
            var DashboardPage = new NavigationPage (new Dashboard(App.UserID));

            InfoPage.Title = "Info";
            //ContactPage.Title = "Contact";
            DashboardPage.Title = "Dashboard";

            this.Children.Add(DashboardPage);
            //this.Children.Add(ContactPage);
            this.Children.Add(InfoPage);
        }
    }
}