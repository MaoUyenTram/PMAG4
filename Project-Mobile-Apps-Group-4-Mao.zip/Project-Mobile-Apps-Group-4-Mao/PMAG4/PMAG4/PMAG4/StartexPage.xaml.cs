﻿using PMAG4.Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PMAG4
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class StartexPage : ContentPage
	{
        //Materiaal: Kolommen met opties -> Opties in de juiste kolommen zetten
        public ObservableCollection<Material> Materials { get; set; }
        public ObservableCollection<Material> Used { get; set; }
        public ObservableCollection<Material> AllMats { get; }
        public ObservableCollection<Material> Quantity { get; set; }
        public ObservableCollection<Material> Quality { get; set; }
        public Material TempMaterial { get; set; }
        public MaterialStep Step { get; set; }
        public int Attempt { get; set; }
        public String Name1 { get; set; }
        public String Name2 { get; set; }

        public event EventHandler StepSucceeded;

        public event EventHandler StepFailed;

        private void OnStepSucceeded()
        {
            StepSucceeded?.Invoke(this, EventArgs.Empty);
        }

        private void OnStepFailed()
        {
            StepFailed?.Invoke(this, EventArgs.Empty);
        }

        public StartexPage (MaterialStep Step, int Attempts)
		{
            InitializeComponent();
            Attempt = Attempts;
            this.Step = Step;
            Materials = new ObservableCollection<Material>();
            Used = new ObservableCollection<Material>(Step.Materials);
            Quality = new ObservableCollection<Material>();
            Quantity = new ObservableCollection<Material>();
            FillMaterials();
            //Name1 = Materials[0].Type;
            //getName2();
            MaterialList.ItemsSource = Materials;
            QuantityList.ItemsSource = Quantity;
            QualityList.ItemsSource = Used;
            MaterialQuestionLabel.Text = Step.Question;
            AttemptLabel.Text = "Poging: " + Attempt.ToString();
        }

        public void FillMaterials()
        {
            Materials = API.GetAllMaterial();
            MaterialList.ItemsSource = Materials;
        }

        /*public void getName2()
        {
            for (int i = 0; i < Materials.Count; i++)
            {
                if (Materials[i].Type != Name1)
                {
                    Name2 = Materials[i].Type;
                }
            }
        }*/

        public void OnMaterialTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            TempMaterial = (Material)e.Item;
        }

        public void OnQuantityButtonClicked(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            if (TempMaterial == null) return;
            Quantity.Add(TempMaterial);
            if (Materials.Contains(TempMaterial)) {
                Materials.Remove(TempMaterial);
            } else
            {
                Quality.Remove(TempMaterial);
            }
            TempMaterial = null;
            if (Quantity.Count == Used.Count)
            {
                if (CheckSolution())
                {
                    OnStepSucceeded();
                    Navigation.PopAsync();
                }
                else
                {
                    Reset();
                }
            }
        }

        public void OnQualityButtonClicked(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            if (TempMaterial == null) return;
            Quality.Add(TempMaterial);
            if (Materials.Contains(TempMaterial))
            {
                Materials.Remove(TempMaterial);
            }
            else
            {
                Quantity.Remove(TempMaterial);
            }
            TempMaterial = null;
            if(Materials.Count == 0)
            {
                if (CheckSolution())
                {
                    OnStepSucceeded();
                    Navigation.PopAsync();
                } else
                {
                    Reset();
                }
            }
        }

        public bool CheckSolution()
        {
            for(int i = 0; i < Used.Count; i++)
            {
                
                
                for (int a = 0; a < Quantity.Count; a++)
                {
                    if ((Used[a].Name.Equals(Quantity.ElementAt(i).Name)))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void Reset()
        {
            if (Attempt == 3)
            {
                DisplayAlert("Feedback", Step.Feedback, "Ok");
            }
            else if (Attempt == 5)
            {
                OnStepFailed();
                Navigation.PopAsync();
            }
            Attempt++;
            AttemptLabel.Text = "Poging: " + Attempt.ToString();
            Materials.Clear();
            Quality.Clear();
            Quantity.Clear();
            FillMaterials();
        }
    }
}