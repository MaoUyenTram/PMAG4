﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using PMAG4;
using PMAG4.Droid;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using Microsoft.Identity.Client;

[assembly: ExportRenderer(typeof(Login), typeof(LoginPageRenderer))]
namespace PMAG4.Droid
{
    class LoginPageRenderer : PageRenderer
    {
        private Login _page;
        public LoginPageRenderer(Context context) : base(context) { }

        protected override void OnElementChanged(ElementChangedEventArgs<Page> e)
        {
            base.OnElementChanged(e);
            _page = e.NewElement as Login;
            var activity = this.Context as Activity;
            //_page.PlatformParameters = new PlatformParameters();
            App.ClientApplication.PlatformParameters = new PlatformParameters(activity);
        }
    }
}