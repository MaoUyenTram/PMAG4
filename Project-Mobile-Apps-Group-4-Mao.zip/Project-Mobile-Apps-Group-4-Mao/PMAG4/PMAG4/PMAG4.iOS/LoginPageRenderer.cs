﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using Microsoft.Identity.Client;
using PMAG4;
using PMAG4.iOS;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(Login), typeof(LoginPageRenderer))]
namespace PMAG4.iOS
{
    class LoginPageRenderer : PageRenderer
    {
        Login _page;
        protected override void OnElementChanged(VisualElementChangedEventArgs e)
        {
            base.OnElementChanged(e);
            _page = e.NewElement as Login;
        }
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            App.ClientApplication.PlatformParameters = new PlatformParameters(this);
        }
    }
}