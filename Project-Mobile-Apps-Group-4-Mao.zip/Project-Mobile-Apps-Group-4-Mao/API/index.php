<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 19.03.18
 * Time: 01:02
 */


header('Location: public/');


?>