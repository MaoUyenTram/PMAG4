<?php

use Slim\Http\Request;
use Slim\Http\Response;

use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\Exception\UnsatisfiedDependencyException;

// Routes

$app->get('/test', function($request, $response, $args){

    $myObj=new stdClass();
	$myObj->message = "TEST SUCCESFULL";
	$myJSON = json_encode($myObj);
	
	return $this->response->withJson($myJSON);
});

$app->get('/getall', function($request, $response, $args){

	$sth = $this->db->prepare("SELECT * FROM uuid");
	$sth->execute();
	$rows = $sth->fetchAll();

	return $this->response->withJson($rows);
});

$app->post('/createUuidRecord', function($request,$response){

	//aanvraag uuid + insert in tabel
	$entity = json_decode($request->getBody());
	$entityversion = 1;

	try {
		$uuid = Uuid::uuid4();
	} catch(UnsatisfiedDependencyException $e){
	    echo 'Caught exception: ' . $e->getMessage() . "\n";
	}
	

	$sql = "INSERT INTO uuid VALUES(:uuid, :sourceid, :entitytype, :entityversion, :source)";
	try {
		$stmt = $this->db->prepare($sql);
        $stmt->bindParam("uuid", $uuid);
        $stmt->bindParam("sourceid", $entity->Source_id);
        $stmt->bindParam("entitytype", $entity->Entity_type);
		$stmt->bindParam("entityversion", $entityversion);
		$stmt->bindParam("source", $entity->Source);
        $stmt->execute();
        $db = null;
        //echo json_encode($entity);
	} catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }


	//response geven van deze rij
	$sql2 = "SELECT * FROM uuid WHERE UUID = ? AND Source = ?";
	$sth = $this->db->prepare($sql2);
	$sth->execute(array($uuid, $entity->Source));
	$rows = $sth->fetchAll();

	return $this->response->withJson($rows);
});

$app->post('/insertUuidRecord', function($request){
	$entity = json_decode($request->getBody());

	$sql = "INSERT INTO uuid VALUES(:uuid, :sourceid, :entitytype, :entityversion, :source)";
	try {
		$stmt = $this->db->prepare($sql);
        $stmt->bindParam("uuid", $entity->Uuid);
        $stmt->bindParam("sourceid", $entity->Source_id);
        $stmt->bindParam("entitytype", $entity->Entity_type);
		$stmt->bindParam("entityversion", $entity->Entity_version);
		$stmt->bindParam("source", $entity->Source);
        $stmt->execute();
        $db = null;
        //echo json_encode($entity);
	} catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
});

$app->put('/updateUuidRecordVersion', function($request, $response){
	$entity = json_decode($request->getBody());

	$sql = "UPDATE uuid SET Entity_version = Entity_version + 1 WHERE UUID = ? AND Source = ?";
	try {
		$stmt = $this->db->prepare($sql);
        $stmt->execute(array($entity->Uuid, $entity->Source));
        $db = null;
        //echo json_encode($entity);
	} catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }


	//response geven van deze rij
	$sql2 = "SELECT Entity_version FROM uuid WHERE UUID = ? AND Source = ?";
	$sth = $this->db->prepare($sql2);
	$sth->execute(array($entity->Uuid, $entity->Source));
	$rows = $sth->fetchAll();

	return $this->response->withJson($rows);

});

$app->put('/updateUuidRecordVersionB', function($request){
	$entity = json_decode($request->getBody());

	$sql = "UPDATE uuid SET Entity_version = ? WHERE UUID = ? AND Source = ?";
	try {
		$stmt = $this->db->prepare($sql);
        $stmt->execute(array($entity->Entity_version,$entity->Uuid, $entity->Source));
        $db = null;
        //echo json_encode($entity);
	} catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }

});

$app->get('/[{name}]', function (Request $request, Response $response, array $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});
