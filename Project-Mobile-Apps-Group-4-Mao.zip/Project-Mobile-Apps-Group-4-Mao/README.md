# Project-Mobile-Apps-Group-4
Project mobile apps for the second year of Dig-X @ EHBrussel

by Group 4:

Cyril Delander: cyril.delander@student.ehb.be
Ief Falot: ief.falot@student.ehb.be
Wissam Nasser: wissam.nasser@student.ehb.be
Mao Uyen Tram: mao.uyen.tram@student.ehb.be
Tom Vanlaer: tom.vanlaer@student.ehb.be

Diary:

14.02.2018:
First lesson: project scope description

21.02.2018:
Second lesson: explanation project in detail for BMLT

28.02.2018:
Database setup (ERD) : v0.1
Wireframes: v0.1
Roadmap: v0.1

07.03.2018:
Database setup (ERD) : v0.2: first version (needs to be upgraded for further features)
Wireframes: v0.1
Roadmap: v0.2

14.03.2018:

21.03.2018:


