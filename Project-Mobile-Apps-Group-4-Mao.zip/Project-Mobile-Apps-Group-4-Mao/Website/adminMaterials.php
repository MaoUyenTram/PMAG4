<?php
session_start();
    
    //redirect function
    function redirect($page){
        header("Location:".$page);
    }

    //destroy and redirect user if not amdin
    if(!isset($_SESSION["admin"])){
        session_destroy();
        redirect("index.php");
    }

?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
        <link rel="stylesheet" href="css/footer.css">
        
        <!-- add ajax and filter scripts -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script type="application/javascript" src="scripts/filter.js"></script>
        
        <title>PMAG4</title>
    </head>

    <body>
        <header class="banner">
            <?php
            //add admin menu
            include_once("scripts/menuadmin.php");
        ?>
        </header>
        <br>
        <main class="main container">
            <h1>Welkom,
                <?php echo $_SESSION["admin"];?>
            </h1>
            <br>
            <h4>
                Alle cursussen
            </h4>
            <section class="row justify-content-center">
                <form role="form" class="form col-sm-6" id="form" action="scripts/filter.php" method="POST">
                    <input type="hidden" name="filterMaterials" id="filterMaterials">
                    <div class="form-group">
                        <input type="submit" class="btn btn-outline-success" value="Bekijk cursussen"> 
                    </div>
                </form>
            </section>
            <section id="filterMaterialsTable" class="row justify-content-center">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">name</th>
                            <th scope="col">description</th>
                            <th scope="col">img</th>
                            <th scope="col">qwalitatief</th>
                        </tr>
                    </thead>
                    <tbody id="tbody">
                    </tbody>
                </table>
            </section>
        </main>
        <br>
        <footer id="footer" role="footer" class="footer bg-dark text-center text-light">
            <p>PMAG 4 | &copy;
                <?php echo date("Y");?>
            </p>
        </footer>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    </body>
</html>