﻿ik heb de website kant van de applicatie gemaakt. de website dient vooral voor leerkrachten en administrators. 
de bedoeling is ook dat studenten later ook via de website hun oefeningen kunnen ingevegen,
maar het hoofddoel van de website is om oefeningen aan te maken en users toe te voegen aan de databse.

een website bouwen leek ons het gemakkelijkste voor leerkrachten om hun oefeningen online te plaatsen. 

Er zijn verschillende mogelijkheden naar gelang de bevoegdheden van de user.

voor admins:
    - users aanmaken en cursussen toevoegen
    - monitoren van users en cursussen
    - toegang blokeren voor bepaalde users (enkel indien echt nodig)

voor leerkrachten:
    - leerlingen toevoegen aan hun cursussen
    - toegang tot platform blokeren voor een bepaalde leerling (enkel te gebruiken indien echt nodig)
    - oefeningen aanmaken in de cursussen waar ze rechten op hebben
    - oefeningen niet zichtbaar te maken voor studenten

voor studenten:
    - leerlingen kunnen enkel de oefeningen bekijken  