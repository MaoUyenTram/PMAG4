<?php
    include_once("../CRUD/DB/UserDB.php");
    include_once("../CRUD/DB/CourseDB.php");
    include_once("../CRUD/DB/StepDB.php");
    include_once("../CRUD/DB/ExerciseDB.php");
    include_once("../CRUD/DB/MethodDB.php");
    include_once("../CRUD/DB/Step_has_MaterialDB.php");
    include_once("../CRUD/DB/Step_has_MethodDB.php");
    include_once("../CRUD/DB/User_has_ExerciseDB.php");
    include_once("../CRUD/DB/MaterialDB.php");
    
    //redirect functie
    function redirect($page){
        header("Location: ../$page");
    }

    //Add User to DB
    if(isset($_POST['saveUser'])){
        //gather information
        $user_email = $_POST["user_email"];
        $user_name = $_POST["user_name"];
        $user_pass = hash('sha256', $_POST["user_pass"]);
        $user_type = $_POST["user_type"];
        
        //user infromation to add user to DB
        $User = new User(NULL, $user_email, $user_name, $user_pass, NULL, $user_type, NULL, NULL);
        UserDB::insertUser($User);
        
        //redirect to the add user page
        redirect("adminUser.php");
    }
    
    //Add Course to DB
    if(isset($_POST['saveCourse'])){
        //gather information
        $course_department = $_POST["course_department"];
        $course_name = $_POST["course_name"];
        $course_year = $_POST["course_year"];
        
        if(!empty($course_department) && !empty($course_name) && !empty($course_year)){
        //user information to add course to DB
        $Course = new Course(NULL, $course_department, $course_name, $course_year, null, null);
        CourseDB::insertCourse($Course);
        }else{
            echo "fout bij het ingeven van uw gegevens";
        }
        //redirect to the add course page
        redirect("adminCursussen.php");
    }
    
    //add exercise and steps
    if(isset($_POST["saveExercise"])){
        //get all the data for exercise
        
        $exerciseName = $_POST["exerciseName"];
        $exerciseDescription = $_POST["exerciseDescription"];
        $deadline = $_POST["deadline"];
        $idcourse = $_POST["cursus"];
        
        //get all information for material
        $questionMaterial = $_POST["questionMaterial"];
        if(isset($_POST["checkboxListItems"])){
            $checkbox = $_POST["checkboxListItems"];
        }
        $feedbackMaterial = $_POST["feedbackMaterial"];
        
        //get all information for method
        $questionMethod = $_POST["questionMethod"];
        $method = htmlspecialchars($_POST["method"]);
        $feedbackMethod = $_POST["feedbackMethod"];
        
        //var dump everything
/*
            var_dump($exerciseName);
            var_dump($exerciseDescription);
            var_dump($deadline);
            var_dump($idcourse);
            var_dump($questionMaterial);
            var_dump($checkbox);
            var_dump($feedbackMaterial);
            var_dump($questionMethod);
            var_dump($method);
            var_dump($feedbackMethod);
*/
        $Exercise = new Exercise(NULL, $exerciseName, $exerciseDescription, $deadline, null, null, $idcourse);
        ExerciseDB::insertExercise($Exercise);

        $ExerciseId = ExerciseDB::getLastExercise();

        foreach($ExerciseId as $eid){
        // add step to DB on step type
    //add material step
        
        if(!empty($questionMaterial) && !empty($checkbox) && !empty($feedbackMaterial)){
            $Step = new Step(NULL, $questionMaterial, NULL, $feedbackMaterial, "Startex", NULL, NULL, $eid->idExercise);
            StepDB::insertStep($Step);
            $idStep = StepDB::getLastStep();
            foreach($idStep as $ids){
                //get all material ids
                foreach($checkbox as $cb){
                    $material = MaterialDB::getMaterialByName($cb);
                    foreach($material as $m){
                        StepHasMaterialDB::AddMaterialToStep($ids->idStep, $m->idMaterial);
                    }
                }
            }
            $Step = new Step(NULL, $questionMaterial, NULL, $feedbackMaterial, "Material", NULL, NULL, $eid->idExercise);
            StepDB::insertStep($Step);
            $idStep = StepDB::getLastStep();
            foreach($idStep as $ids){
                //get all material ids
                foreach($checkbox as $cb){
                    $material = MaterialDB::getMaterialByName($cb);
                    foreach($material as $m){
                        StepHasMaterialDB::AddMaterialToStep($ids->idStep, $m->idMaterial);
                    }
                }
            }
        }
        if(!empty($questionMethod) && !empty($method) && !empty($feedbackMethod)){
            //add step to DB
            $Step = new Step(NULL, $questionMethod, NULL, feedbackMethod, "Method", NULL, NULL, $eid->idExercise);
            StepDB::insertStep($Step);
            //get last step id
            $idStep = StepDB::getLastStep();
            foreach($idStep as $ids){
                //add mehtod to DB
                $methods = new Method(null, $method, 1, null, null);
                MethodDB::insertMethod($Methods);
                //get last method id
                $idMethod = MethodDB::getLastmethod();
                foreach($idMethod as $idmet){
                    StepHasMethodDB::AddMethodToStep($ids->idStep, $idmet->idMethod);
                }
            }
        }
    }
        
    //add method step
       
       //redirect("leerkrachtcursussen.php");
        
    }
?>