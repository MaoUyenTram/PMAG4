<?php
    session_start();
    include_once("../CRUD/DB/UserDB.php");
    include_once("../CRUD/DB/User_has_CourseDB.php");
    include_once("../CRUD/DB/CourseDB.php");
    include_once("../CRUD/DB/MaterialDB.php");

// teachers see all their courses at page load

    //get the ID of the teacher for DB filtering
    $docentName = $_SESSION["leerkracht"];

    $ids = UserDB::getUserId($docentName);
    foreach($ids as $id){
        //loop all courses of a teacher based on his/her ID
        $Courses = UserHasCourseDB::getCoursesfromUser($id->idUser);
        
        //loop all courses
        foreach($Courses as $course){
            // get names of the courses
            $courseNames = CourseDB::getCourseById($course->Course_idCourse);
            //loop all names of the courses
            foreach ($courseNames as $courseOption){
                $data = "<option value ='".$courseOption->idCourse."'>".$courseOption->course_name."</option>";
                //check if data is correct and send
                if(!empty($data)){
                    echo($data);
                }else{
                    echo("geen resultaat");
                }
            }
        }
    }

/*
IIIIIIIIEEEEEEEEEEFFFFFFF
    hier zou de code moeten komen om via ajax
    om de materialen in checklist te zetten als checkboxen
    heb al geprobeerd maar ging helemaal fout 

*/


/*
IEF DEZE CODE NIET BEKIJKEN WORDT NIEMEER GEBRUIKT 

replace funciton for special characters inside database 
(THIS CODE IS NOT IMPLEMENTED ANYORE BUT MIGHT BE NEEDED LATER)

function replace($text){
    $text = str_replace(" ", "",$text);
    $text = str_replace("(", "",$text);
    $text = str_replace(")", "",$text);
    return $text;    
}*/
?>