<?php
    session_start();
    include_once("../CRUD/DB/MaterialDB.php");

// teachers see all their courses at page load

    //get the ID of the teacher for DB filtering

    $materials = materialDB::getAllMaterials();
    foreach($materials as $material){
        $data = "<input type='checkbox' name='checkboxListItems[]' id='".$material->idMaterial."' value='".$material->material_name."'><label for='".$material->idMaterial."'>".$material->material_name."</label><br></div>";
        
        //var_dump($data);
                //check if data is correct and send
                if(!empty($data)){
                    echo($data);
                }else{
                    echo("geen resultaat");
                }
            }

/*
IIIIIIIIEEEEEEEEEEFFFFFFF
    hier zou de code moeten komen om via ajax
    om de materialen in checklist te zetten als checkboxen
    heb al geprobeerd maar ging helemaal fout 

*/


/*
IEF DEZE CODE NIET BEKIJKEN WORDT NIEMEER GEBRUIKT 

replace funciton for special characters inside database 
(THIS CODE IS NOT IMPLEMENTED ANYORE BUT MIGHT BE NEEDED LATER)

function replace($text){
    $text = str_replace(" ", "",$text);
    $text = str_replace("(", "",$text);
    $text = str_replace(")", "",$text);
    return $text;    
}*/
?>