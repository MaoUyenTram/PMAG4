<!--MENU FOR ADMIN-->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="admin.php">PMAG4 Admin</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="adminCursussen.php">Cursussen Toevoegen</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminAllCursussen.php">Alle Cursussen</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminUser.php">User Toevoegen</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminAllUsers.php">Alle Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminAccess.php">Users in cursus</a>
            </li>
        </ul>
        <?php
        if(isset($_SESSION["admin"])){
            
        ?>
            <form role="form" method="POST" action="scripts/login.php" class="form-inline my-2 my-lg-0">
                <button class="btn btn-outline-danger my-2 my-sm-0" type="submit" name="disconnect">Logout</button>
            </form>
            <?php
        }
        ?>
    </div>
</nav>
