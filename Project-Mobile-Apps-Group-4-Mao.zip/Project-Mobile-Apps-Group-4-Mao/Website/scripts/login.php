<?php
    session_start();

    //redirect function
    function redirect($page){
        header("Location: ../$page");
    }

    //disconnect user
    if(isset($_POST["disconnect"])){
        session_destroy();
        redirect("index.php");
    }

    //login the user
    if(isset($_POST["login"])){
        //gather information
        $user_email = $_POST["email"];
        $user_pass = $_POST["password"];
        
        //insert userDB functions
        include_once("../CRUD/DB/UserDB.php");
        
        //check if information is correct
        if(empty($user_email) || empty($user_pass)){
            //redirect if user email or password is not correct
            redirect("index.php");
        }else{
            
            //using the login function
            $user_pass = hash('sha256',$user_pass);
            $users = userDB::logIn($user_email, $user_pass);
            
            //loop users
            if(!empty($users)){
                foreach($users as $user){
                    
                    //check type of user and redirect to correct page 
                    if($user->user_type=="TEACHER"){
                        $_SESSION["leerkracht"] = $user->user_name;
                        redirect("leerkracht.php");
                        
                    }elseif($user->user_type=="STUDENT"){
                        $_SESSION["leerling"] = $user->user_name;
                        redirect("leerling.php");
                        
                    }elseif($user->user_type=="ADMIN"){
                        $_SESSION["admin"] = $user->user_name;
                        redirect("admin.php");                
                    }
                }
            }else{
                redirect("index.php");
            }
        }
}
?>