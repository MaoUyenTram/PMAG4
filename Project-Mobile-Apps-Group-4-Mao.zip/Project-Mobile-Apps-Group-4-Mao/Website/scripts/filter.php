<?php
    include_once("../CRUD/DB/CourseDB.php");
    include_once("../CRUD/DB/UserDB.php");
    include_once("../CRUD/DB/User_has_CourseDB.php");
    include_once("../CRUD/DB/User_has_Course_viewDB.php");
    include_once("../CRUD/DB/MaterialDB.php");
    
//filter cursus tabel
if(isset($_POST["filterCourse"])){
    
    //check incomming information
    if(isset($_POST["course_year"]) && isset($_POST["course_department"])){
        if(!empty($_POST["course_year"]) && !empty($_POST["course_department"])){
        
            //use gathered information and select courses
            $year = $_POST["course_year"];
            $department = $_POST["course_department"];
            $Courses = CourseDB::getSelectedCourses($department, $year); 
        
            //loop all courses
            foreach($Courses as $course){
                $data = "<tr scope='row'>".
                        "<td>".$course->idCourse."</td>".
                        "<td>".$course->course_department."</td>".
                        "<td>".$course->course_name."</td>".
                        "<td>".$course->course_year."</td>".
                        "<td>".$course->timestampLastUpdated."</td>".
                        "<td>".$course->timestampCreated."</td></tr>";
                
                //check data if correct and send
                if(!empty($data)){
                    echo($data);
                }else{
                    echo("geen resultaat");
                }
            }
        }
    }
}

//filter user tabel
if(isset($_POST["filterUsers"])){
    
    //check incomming information
    if(isset($_POST["user_type"]) && (!empty($_POST["user_type"]))){ 
        
        //fall back for boolean
        if(isset($_POST["user_active"])){
            $user_active = 1;
        }else{
            $user_active = 0;
        }
        
        //user gathered information to select users
        $user_type = $_POST["user_type"];
        $Users = UserDB::getSelectedUsers($user_active, $user_type); 
        
        //loop all users
        foreach($Users as $user){
            $data = "<tr scope='row'>".
                "<td>".$user->idUser."</td>".
                "<td>".$user->user_email."</td>".
                "<td>".$user->user_name."</td>".
                "<td>".$user->user_active."</td>".
                "<td>".$user->user_type."</td>".
                "<td>".$user->timestampLastUpdated."</td>".
                "<td>".$user->timestampCreated."</td></tr>";
            
            //check data if correct and send
            if(!empty($data)){
                echo($data);
            }else{
                echo("geen resultaat");
            }
        }
    }
}

//filter user has courses
if(isset($_POST["filterUserHasCourse"])){
    
    //user information and function to select users and courses
    $department = $_POST["course_department"];
    $UsersHasCourses = UserHasCourseViewDB::getSelected($department);
    
    //loop all users and courses
    foreach($UsersHasCourses as $UhCv){
        $data = "<tr scope='row'>".
                    "<td>".$UhCv->User_idUser."</td>".
                    "<td>".$UhCv->user_name."</td>".
                    "<td>".$UhCv->Course_idCourse."</td>".
                    "<td>".$UhCv->course_name."</td></tr>";
        
        //check if data is correct and send
        if(!empty($data)){
            echo($data);
        }else{
            echo("geen resultaat");
        }
    }
}

//filter all materials
if(isset($_POST["filterMaterials"])){
    
    //use MaterialDb function to select materials
    $Materials = MaterialDB::getAllMaterials();
    
    //loop all materials
    foreach($Materials as $m){
        $data = "<tr scope='row'>".
                    "<td>".$m->idMaterials."</td>".
                    "<td>".$m->material_name."</td>".
                    "<td>".$m->material_description."</td>".
                    "<td><img alt='".$m->material_name."' src='".$m->material_image."' width='310' height='210'></td>".
                    "<td>".$m->material_qwalitatief."</td></tr>";
        
        //check if data is correct and send
        if(!empty($data)){
            echo($data);
        }else{
            echo("geen resultaat");
        }
    }
}


?>