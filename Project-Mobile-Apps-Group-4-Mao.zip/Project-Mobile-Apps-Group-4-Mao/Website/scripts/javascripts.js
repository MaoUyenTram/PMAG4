function stapType() {
    var y = document.getElementById("stepType").value;
   
    switch (y) {
        case "material":
        console.log("materiaal toevoegen");
            document.getElementById("step").innerHTML = "<div class='border border-primary rounded p-4'><div class='form-group'><label for='questionMaterial'>Vraag voor materiaal: </label><input type='text' name='questionMaterial' placeholder='vraag' class='form-control'></div><div name='checkList' id='checkList' class='form-group'></div><div class='form-group'><label for='feedbackMaterial'>Feedback materiaal</label><input type='text' placeholder='feedback' name='feedbackMaterial' id='feedbackMaterial' class='form-control'></div>";
            voegMateriaal();
            
        break;
        case "method":
            document.getElementById("step").innerHTML += "<div class='border border-primary rounded p-4'><div class='form-group'><label for='questionMethod'>Vraag voor werkwijze: </label><input type='text' name='questionMethod' placeholder='vraag' class='form-control'></div><div id='methoden' class='form-group'><label for='0'>Werkwijze</label><textarea class='form-control' rows='5' cols='45' name='method' id='method'></textarea></div><div class='form-group'><label for='feedbackMethod'>Feedback werkwijze</label><input type='text' placeholder='feedback' name='feedbackMethod' id='feedbackMethod' class='form-control'></div></div>";
            break;
        default:
            console.log("niks toegevoegd");
    }
}


function addForm2() {
    
var d = new Date();
  var x = document.getElementById("lijstCurssusen").value;
    
    
  if (x == 0) {
      document.getElementById("formAddExercise").remove();
  } else {
      document.getElementById("addExercise").innerHTML = "<form name='"+x+"' id='formAddExercise' class='form col-sm-6' method='POST' action='scripts/voegToe.php'>" +
      "<br><input type='hidden' value='"+x+"' name='cursus'>" +
      "<div class='form-group'><label for='exerciseName'>Naam Oefening: </label><input class='form-control' type='text' placeholder='naam oefening' name='exerciseName'></div>" +
      "<div class='form-group'><label for='exerciseDescription'>Uitleg van oefening: </label><br><textarea class='form-control' name='exerciseDescription' cols='45' rows='5'></textarea></div>" +
      "<div class='form-group'><label for='deadline'>Deadline: </label><br><input class='form-control' type='date' name='deadline' max='" + d.getDate()+"'></div>" +
        "<div id='step'></div>"+
      "<label for='stepType'>Voeg stap toe</label><select class='form-control' name='stepType' id='stepType' onchange='stapType()'>" +
      "<option value='none'>--</option>" +
      "<option value='material'>Materiaal</option>" +
      "<option value='method'>Werkwijze</option>" +
      "</select>"+
      "<br><input class='btn btn-primary form-control' type='submit' value='Bewaar Oefening' name='saveExercise'>";

    }
}

$(document).ready(function filterTable() {
    var form = $('#form'); 
        form.submit(function(e){
        e.preventDefault();
        
        $.ajax({
            type: "POST",
            url: form.attr("action"),
            data_type: "html",
            data: form.serialize(),
            success: function(data){
               $("tbody").append(data);
                form.remove();
            }
        });
    });
});

$(document).ready(function addForm() {
        $.ajax({
            type: "POST",
            url: "scripts/voegOefeningToe.php",
            data_type: "html",
            success: function(data){
               $("#lijstCurssusen").append(data);
            }
        });
    });

function voegMateriaal(){
       $.ajax({
            type: "POST",
            url: "scripts/voegMateriaalToe.php",
            data_type: "html",
            success: function(data){
               $("#checkList").append(data);
            }
        });
}
