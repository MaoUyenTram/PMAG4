-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Course` (
  `idCourse` INT(11) NOT NULL AUTO_INCREMENT,
  `course_department` ENUM('Biomedische', 'Voedingskunde', 'Vroedkunde', 'Verpleegkunde', 'Pediatrie', 'Zorgmanagement') NOT NULL,
  `course_name` VARCHAR(45) NOT NULL,
  `course_year` VARCHAR(45) NOT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idCourse`))
ENGINE = InnoDB
AUTO_INCREMENT = 151
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`Exercise`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Exercise` (
  `idExercise` INT(11) NOT NULL AUTO_INCREMENT,
  `exercise_name` VARCHAR(45) NOT NULL,
  `exercise_description` VARCHAR(255) NOT NULL,
  `exercise_deadline` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `Course_idCourse` INT(11) NOT NULL,
  PRIMARY KEY (`idExercise`, `Course_idCourse`),
  INDEX `fk_Exercise_Course1_idx` (`Course_idCourse` ASC),
  CONSTRAINT `fk_Exercise_Course1`
    FOREIGN KEY (`Course_idCourse`)
    REFERENCES `mydb`.`Course` (`idCourse`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 21
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`Material`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Material` (
  `idMaterial` INT(11) NOT NULL AUTO_INCREMENT,
  `material_name` VARCHAR(45) NOT NULL,
  `material_description` VARCHAR(255) NULL DEFAULT NULL,
  `material_image` VARCHAR(255) NOT NULL,
  `material_qualitative` TINYINT(4) NOT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMaterial`))
ENGINE = InnoDB
AUTO_INCREMENT = 29
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`Method`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Method` (
  `idMethod` INT(11) NOT NULL AUTO_INCREMENT,
  `text` VARCHAR(255) NOT NULL,
  `stepNumber` INT(11) NULL DEFAULT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMethod`))
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`Step`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Step` (
  `idStep` INT(11) NOT NULL AUTO_INCREMENT,
  `question` VARCHAR(255) NOT NULL,
  `answer` VARCHAR(255) NULL DEFAULT NULL,
  `feedback` VARCHAR(255) NULL DEFAULT NULL,
  `stepType` VARCHAR(55) NULL DEFAULT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `Exercise_idExercise` INT(11) NOT NULL,
  PRIMARY KEY (`idStep`, `Exercise_idExercise`),
  INDEX `fk_Step_Exercise1_idx` (`Exercise_idExercise` ASC),
  CONSTRAINT `fk_Step_Exercise1`
    FOREIGN KEY (`Exercise_idExercise`)
    REFERENCES `mydb`.`Exercise` (`idExercise`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 11
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`Step_has_Material`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Step_has_Material` (
  `Step_idStep` INT(11) NOT NULL,
  `Material_idMaterial` INT(11) NOT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Step_idStep`, `Material_idMaterial`),
  INDEX `fk_Steps_has_Materials_Steps1_idx` (`Step_idStep` ASC),
  INDEX `fk_Steps_has_Materials_Materials1` (`Material_idMaterial` ASC),
  CONSTRAINT `fk_Steps_has_Materials_Materials1`
    FOREIGN KEY (`Material_idMaterial`)
    REFERENCES `mydb`.`Material` (`idMaterial`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Steps_has_Materials_Steps1`
    FOREIGN KEY (`Step_idStep`)
    REFERENCES `mydb`.`Step` (`idStep`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`Step_has_Method`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Step_has_Method` (
  `Step_idStep` INT(11) NOT NULL,
  `Method_idMethod` INT(11) NOT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Step_idStep`, `Method_idMethod`),
  INDEX `fk_Steps_has_Methods_Methods1_idx` (`Method_idMethod` ASC),
  INDEX `fk_Steps_has_Methods_Steps1_idx` (`Step_idStep` ASC),
  CONSTRAINT `fk_Steps_has_Methods_Methods1`
    FOREIGN KEY (`Method_idMethod`)
    REFERENCES `mydb`.`Method` (`idMethod`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Steps_has_Methods_Steps1`
    FOREIGN KEY (`Step_idStep`)
    REFERENCES `mydb`.`Step` (`idStep`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`User` (
  `idUser` INT(11) NOT NULL AUTO_INCREMENT,
  `user_email` VARCHAR(255) NOT NULL,
  `user_name` VARCHAR(255) NOT NULL,
  `user_pass` VARCHAR(255) NOT NULL,
  `user_active` TINYINT(1) NOT NULL DEFAULT '1',
  `user_type` ENUM('ADMIN', 'TEACHER', 'STUDENT') NOT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idUser`))
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`User_has_Course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`User_has_Course` (
  `User_idUser` INT(11) NOT NULL,
  `Course_idCourse` INT(11) NOT NULL,
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`User_idUser`, `Course_idCourse`),
  INDEX `fk_Users_has_Courses_Users1_idx` (`User_idUser` ASC),
  INDEX `fk_Users_has_Courses_Courses1` (`Course_idCourse` ASC),
  CONSTRAINT `fk_Users_has_Courses_Courses1`
    FOREIGN KEY (`Course_idCourse`)
    REFERENCES `mydb`.`Course` (`idCourse`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Users_has_Courses_Users1`
    FOREIGN KEY (`User_idUser`)
    REFERENCES `mydb`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;


-- -----------------------------------------------------
-- Table `mydb`.`User_has_Exercise`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`User_has_Exercise` (
  `User_idUser` INT(11) NOT NULL,
  `Exercise_idExercise` INT(11) NOT NULL,
  `passed` TINYINT(4) NOT NULL DEFAULT '0',
  `attempts` INT(10) UNSIGNED NOT NULL DEFAULT '1',
  `timestampLastUpdated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestampCreated` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`User_idUser`, `Exercise_idExercise`),
  INDEX `fk_Users_has_Exercises_Users1_idx` (`User_idUser` ASC),
  INDEX `fk_Users_has_Exercises_Exercises1` (`Exercise_idExercise` ASC),
  CONSTRAINT `fk_Users_has_Exercises_Exercises1`
    FOREIGN KEY (`Exercise_idExercise`)
    REFERENCES `mydb`.`Exercise` (`idExercise`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Users_has_Exercises_Users1`
    FOREIGN KEY (`User_idUser`)
    REFERENCES `mydb`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
