<?php
include_once("../CRUD/DATA/Exercise.php");
include_once("DBFactory.php");

class ExerciseDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //insert new exercise
    public static function insertExercise($Exercise){
        //var_dump($Exercise);
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Exercise(idExercise, exercise_name, exercise_description, exercise_deadline, Course_idCourse)values(null,'?','?','?',?)",array($Exercise->exercise_name, $Exercise->exercise_description, $Exercise->exercise_deadline, $Exercise->Course_idCourse));
    }
    
    //update Exercise
    public static function updateExercise($Exercise){
        return $con = self::getConnection()->executeUpdate("UPDATE Exercise SET exercise_name = '$Exercise->exercise_name', exercise_description= '$Exercise->exercise_description', exercise_deadline = '$Exercise->exercise_deadline', Course_idCourse = '$Exercise->Course_idCourse' WHERE idExercise = $Exercise->idExercise;");
    }
    
    //get all Exercises
    public static function getAllExercises(){
        //Prepare query
        $sql = "SELECT * FROM Exercise";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $exercise = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $exercise;
        }
        
        
        return $resultsArray;
    }  
    
    //get exercise by id
    public static function getExerciseById($idExercise){
        //Prepare query
        $sql = "SELECT * FROM Exercise WHERE idExercise = $idExercise";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $exercise = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $exercise;
        }
        
        
        return $resultsArray;
    }  
    
    //select last exercise id
    public static function getLastExercise(){
        //Prepare query
        $sql = "SELECT * FROM Exercise ORDER BY idExercise DESC LIMIT 1;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $exercise = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $exercise;
        }
        
        
        return $resultsArray;
    }
    //create Exercise object
    public static function convertToObject($row){
        return new Exercise(
            $row["idExercise"],
            $row["exercise_name"],
            $row["exercise_description"],
            $row["exercise_deadline"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"],
            $row["Course_idCourse"]
        );
    }
}
?>
