<?php
include_once("../CRUD/DATA/User_has_Course.php");
include_once("DBFactory.php");

class UserHasCourseDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //insert a user to a course
    public static function AddUserToCourse($idUser, $idCourse){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO User_has_Course (User_idUser, Course_idCourse) values (?,?)", array($idUser, $idCourse));
    }
    
    //get all courses from specific user
    public static function getCoursesFromUser($idUser){
        $sql = "SELECT * FROM User_has_Course WHERE User_idUser = $idUser;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            //convert to objects
            $UhC = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $UhC;
        }
        return $resultsArray;
    }
    
    //get all users and courses from a department
     public static function getSelected($course_department){
        //Prepare query
        $sql = "SELECT uc.User_idUser, u.user_name, uc.Course_idCourse, uc.timestampLastUpdated, uc.timestampCreated
                FROM User_has_Course uc, Course c, User u
                WHERE uc.Course_idCourse = c.idCourse 
                AND uc.User_idUser = u.idUser 
                AND c.course_department = '$course_department';";
       
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            //convert to objects
            $UhC = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $UhC;
        }    
        return $resultsArray;
    }
    
    // create user has course object
    public static function convertToObject($row){
        return new UserHasCourse(
            $row["User_idUser"],
            $row["Course_idCourse"],
            $row["timestampSinceLastBan"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
