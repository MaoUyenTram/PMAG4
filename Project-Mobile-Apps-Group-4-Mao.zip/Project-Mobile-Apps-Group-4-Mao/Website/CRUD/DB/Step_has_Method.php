<?php
include_once("../CRUD/DATA/Step_has_Method.php");
include_once("DBFactory.php");

class StepHasMethodDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //insert method to step
    public static function AddMethodToStep($idStep, $idMehtod){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Step_has_Method (Step_idStep, Method_idMethod) values (?,?)", array($idStep, $idMethod));
    }
    
    //get all Methods from specific step
    public static function getMethodsFromStep($idStep){
        $sql = "SELECT * FROM Step_has_Method WHERE Step_idStep = $idStep;";
        
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $ShM = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $ShM;
        }    
        return $resultsArray;
    }
    
    //get specific step from method id
     public static function getStepFromMethod($idMethod){
        $sql = "SELECT * FROM Step_has_Method WHERE Method_idMethod = $idMethod;";
        
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $ShM = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $ShM;
        }    
        return $resultsArray;
    }
    
    // create Step with method object
    public static function convertToObject($row){
        return new StephasMethod(
            $row["Step_idStep"],
            $row["Method_idMethod"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
