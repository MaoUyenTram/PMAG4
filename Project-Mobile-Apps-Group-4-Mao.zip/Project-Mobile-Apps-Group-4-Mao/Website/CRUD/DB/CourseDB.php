<?php
include_once("../CRUD/DATA/Course.php");
include_once("DBFactory.php");

class CourseDB{
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    // insert new COURSE
    public static function insertCourse($Course){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Course(idCourse, course_department, course_name, course_year) VALUES (null,?,?,?)", array($Course->idCourse, $Course->course_department, $Course->course_name, $Course->course_year));
    }
    
    //update Course
    public static function updateCourse($Course){
        return $con = self::getConnection()->executeUpdate("UPDATE Course SET course_department ='$Course->course_department', course_name = '$Course->course_name', course_year = $Course->course_year WHERE idCourse = $Course->idCourse;");
    }
    
    //get all Courses
    public static function getAllCourses(){
        //Prepare query
        $sql = "SELECT * FROM Course";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $course = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $course;
        }
        
        
        return $resultsArray;
    }
    
    //get course by id
    public static function getCourseById($CourseId){
        //Prepare query
        $sql = "SELECT * FROM Course WHERE idCourse = $CourseId;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();

            //convert to objects
            $course = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $course;
        }
        
        
        return $resultsArray;
    }
    
    //select courses by department and year of study
    public static function getSelectedCourses($department, $year){
        //Prepare query
        $sql = "SELECT * FROM Course WHERE course_department = '$department' AND course_year = '$year'";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();

            //convert to objects
            $course = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $course;
        }
        
        
        return $resultsArray;
    }
   
    //create Course object
    public static function convertToObject($row){
        return new Course(
            $row["idCourse"],
            $row["course_department"],
            $row["course_name"], 
            $row["course_year"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
            
        );
    }
}

?>
