<?php
include_once("Database.php");
    class DatabaseFactory{
        //singleton
        private static $conn;
        
        //get database
        public static function getDatabase(){
            if(self::$conn==null){
                $url = "dt5.ehb.be";
                $user = "MobileAppsGr";
                $passw = "ASh2bM9";
                $db = "MobileAppsGr";
                self::$conn = new Database($url, $user, $passw, $db);
            }
            return self::$conn;
        }
    }
?>