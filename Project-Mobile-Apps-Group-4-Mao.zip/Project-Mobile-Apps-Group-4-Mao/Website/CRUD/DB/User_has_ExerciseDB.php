<?php
include_once("../CRUD/DATA/User_has_Exercise.php");
include_once("DBFactory.php");

class UserHasExerciseDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //insert a user to a Exercise
    public static function AddUserToExercise($idUser, $idExercise){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO User_has_Exercise (User_idUser, Exercise_idExercise, passed, attempts) values (?,?, null, null)", array($idUser, $idExercise));
    }
    
    //get all Exercises from specific user
    public static function getExerciseFromUser($idUser){
        $sql = "SELECT * FROM User_has_Exercise WHERE User_idUser = $idUser;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            //convert to objects
            $UhE = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $UhE;
        }
        return $resultsArray;
    }
    
    //get all users from specific Exercises 
     public static function getUsersFromExercise($Exercise_idExercise){
        //Prepare query
        $sql = "SELECT u.user_name, ue.Exercise_idExercise, ue.passed, ue.attempts
                FROM User_has_Exercise ue, Exercise c, User u
                WHERE ue.Exercise_idExercise = c.idExercise 
                AND ue.User_idUser = u.idUser 
                AND c.idExercise = '$Exercise_idExercise';";
       
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            //convert to objects
            $UhE = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $UhE;
        }    
        return $resultsArray;
    }
    
    // create user has exercise object
    public static function convertToObject($row){
        return new UserHasExercise(
            $row["User_idUser"],
            $row["Exercise_idExercise"],
            $row["passed"],
            $row["attempts"],
            $row["timestampSinceLastBan"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
