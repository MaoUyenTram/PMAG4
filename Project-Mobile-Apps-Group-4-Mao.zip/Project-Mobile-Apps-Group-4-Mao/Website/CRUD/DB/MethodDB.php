<?php
include_once("../CRUD/DATA/Method.php");
include_once("DBFactory.php");

class MethodDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    // insert new Method
    public static function insertMethod($Method){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Method(idMethod, text, stepNumber) VALUES (null,?,?)", array($Mehtod->idMethod, $Mehtod->text, $Mehtod->stepNumber));
    }
    
    //update Method
    public static function updateMethod($Method){
        return $con = self::getConnection()->executeUpdate("UPDATE Method SET text = '$Method->text' , stepNumber = $Method->stepNumber, WHERE idMethod = $Method->idMethod;");
    }
    
    //get all methods
    public static function getAllMethod(){
        //Prepare query
        $sql = "SELECT * FROM Method";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $method = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $method;
        }
        
        
        return $resultsArray;
    }  
    //get last mehtod
    public static function getLastMethod(){
        //Prepare query
        $sql = "SELECT * FROM Method ORDER BY idMethod DESC LIMIT 1;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $exercise = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $exercise;
        }
        
        
        return $resultsArray;
    }
    //get method by id
    public static function getMethodById($idMethod){
        //Prepre sql
        $sql = "SELECT * FROM Method WHERE idMethod = $idMethod;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $method = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $method;
        }
        
        
        return $resultsArray;
    }
    
    // create Method object
    public static function convertToObject($row){
        return new Method(
            $row["idMethod"],
            $row["text"],
            $row["stepNumber"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
