<?php
include_once("../CRUD/DATA/User_has_Course_view.php");
include_once("DBFactory.php");

class UserHasCourseViewDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //get all courses from specific user
    public static function getCoursesFromUser($idUser){
        $sql = "SELECT * FROM User_has_Course WHERE User_idUser = $idUser;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $user = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $user;
        }
        return $resultsArray;
    }
    
    //get all users and courses from department
    public static function getSelected($course_department){
        //Prepare query
        $sql = "SELECT uc.User_idUser, u.user_name, uc.Course_idCourse, c.course_name
                FROM User_has_Course uc, Course c, User u
                WHERE uc.Course_idCourse = c.idCourse 
                AND uc.User_idUser = u.idUser 
                AND c.course_department = '$course_department';";
       
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $UhCv = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $UhCv;
        }
        return $resultsArray;
    }
    
    // create user has course object
    public static function convertToObject($row){
        return new UserHasCourseView(
            $row["User_idUser"],
            $row["user_name"],
            $row["Course_idCourse"],
            $row["course_name"]
        );
    }
}
?>
