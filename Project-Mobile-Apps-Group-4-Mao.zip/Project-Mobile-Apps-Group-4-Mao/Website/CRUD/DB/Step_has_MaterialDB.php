<?php
include_once("DBFactory.php");
include_once("../CRUD/DATA/Step_has_Material.php");

class StepHasMaterialDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //insert material to step
    public static function AddMaterialToStep($idStep, $idMaterial){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Step_has_Material(Step_idStep, Material_idMaterial) VALUES (?,?)", array($idStep, $idMaterial));
    }
    
    //get all Material from specific step
    public static function getMaterialFromStep($idStep){
        $sql = "SELECT * FROM Step_has_Material WHERE Step_idStep = $idStep;";
        
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $ShM = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $ShM;
        }    
        return $resultsArray;
    }
    
    //get specific step from material id
     public static function getStepFromMaterial($idMaterial){
        $sql = "SELECT * FROM Step_has_Material WHERE Material_idMaterial = $idMaterial;";
        
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $ShM = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $ShM;
        }    
        return $resultsArray;
    }
    
    // create Step with material object
    public static function convertToObject($row){
        return new StepHasMaterial(
            $row["Step_idStep"],
            $row["Material_idMaterial"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
