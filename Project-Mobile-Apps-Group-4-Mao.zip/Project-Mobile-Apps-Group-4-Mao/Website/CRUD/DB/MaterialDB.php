<?php
include_once("../CRUD/DATA/Material.php");
include_once("DBFactory.php");

class MaterialDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //insert new material
    public static function insertMaterial($Material){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Material (idMaterial, material_name, material_description, material_image, material_qualitative) values (null,?,?,?,?)", array($Material->idMaterial, $Material->material_name, $Material->material_description, $Material->material_image, $Material->material_qualitative));
    }
    
    //update Material
    public static function updateMaterial($Material){
        return $con = self::getConnection()->executeUpdate("UPDATE Material SET material_name= '$Material->material_name', material_description = '$Material->material_description', material_image = '$Material->material_image', material_qualitative = $Material->material_qualitative WHERE idMaterial = '$Material->idMaterial';");
    }
    
    //get all materials
    public static function getAllMaterials(){
        //Prepare query
        $sql = "SELECT * FROM Material";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $material = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $material;
        }
        
        
        return $resultsArray;
    }  
    
    //get material by id
    public static function getMaterialById($idMaterial){
        //Prepare query
        $sql = "SELECT * FROM Material WHERE idMaterial = $idMaterial";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $material = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $material;
        }
        
        
        return $resultsArray;
    }  
    //get material id by material name
   public static function getMaterialByName($materialName){
        //Prepare query
        $sql = "SELECT * FROM Material WHERE material_name = '$materialName'";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $material = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $material;
        }
        
        
        return $resultsArray;
    }  
    //create Material object
    public static function convertToObject($row){
        return new Material(
            $row["idMaterial"],
            $row["material_name"],
            $row["material_description"],
            $row["material_image"],
            $row["material_qualitative"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
