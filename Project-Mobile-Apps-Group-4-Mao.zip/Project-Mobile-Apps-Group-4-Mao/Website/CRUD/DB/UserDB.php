<?php
include_once("../CRUD/DATA/User.php");
include_once("DBFactory.php");

// CRUD POST
class UserDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    //log the user in
    public static function logIn($user_email, $user_pass){
        //Prepare query
        $sql = "SELECT * FROM User WHERE user_email ='".$user_email."' AND user_pass = '".$user_pass."' AND user_active = 1;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            //convert to objects
            $user = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $user;
        }
        return $resultsArray;
        
    }
    
    //insert user to DB
    public static function insertUser($User){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO User (idUser, user_email, user_name, user_pass, user_type) values (null,?,?,?,?)", array($User->idUser, $User->user_email, $User->user_name, $User->user_pass, $User->user_type));
    }
    
    //update User
    public static function updateStep($User){
        return $con = self::getConnection()->executeUpdate("UPDATE User SET user_email = $User->user_email, user_name = $User->user_name , user_pass = $User->user_pass, user_active = $User->user_active, user_type = $User->user_type WHERE 1 idUser = $User->idUser;");
    }
    
    
    //get all users
    public static function getAllUsers(){
        //Prepare query
        $sql = "SELECT * FROM User";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            //convert to objects
            $user = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $user;
        }
        return $resultsArray;
    }
    
    //get id of user based on name of user
    public static function getUserId($user_name){
        //Prepare query
        $sql = "SELECT * FROM User WHERE user_name = '$user_name';";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();   
            //convert to objects
            $user = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $user;
        }
        return $resultsArray;
    }
    
    //get all users based on type and if active or not
    public static function getSelectedUsers($user_active, $user_type){
        //Prepare query
        $sql = "SELECT * FROM User WHERE  user_active = '$user_active' AND user_type='$user_type'";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            //convert to objects
            $user = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $user;
        }
        return $resultsArray;
    }
    
    //disable a user based on id
    public static function deactiveUser($idUser){
        return self::getConnection()->executeQuery("UPDATE User SET user_active=0 WHERE idUser=$idUser;");
    }
    
    //enable a user based on id
    public static function activeUser($idUser){
        return self::getConnection()->executeQuery("UPDATE User SET user_active=1 WHERE idUser=$idUser;");
    }
    
    // create User object
    public static function convertToObject($row){
        return new User(
            $row["idUser"],
            $row["user_email"],
            $row["user_name"], 
            $row["user_pass"],
            $row["user_active"],
            $row["user_type"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"]
        );
    }
}
?>
