<?php
include_once("../CRUD/DATA/Step.php");
include_once("DBFactory.php");

class StepDB{
   
    //getting connection
    private static function getConnection(){
        return DatabaseFactory::getDatabase();
    }
    
    // insert new Step
    public static function insertStep($Step){
       //Prepare query
        return $con = self::getConnection()->executeInsert("INSERT INTO Step(idStep, question, answer, feedback, stepType, Exercise_idExercise) VALUES (null,'?','?','?','?',?)", array($Step->question, $Step->answer, $Step->feedback, $Step->stepType, $Step->Exercise_idExercise));
    }
    
    //update Step
    public static function updateStep($Step){
        return $con = self::getConnection()->executeUpdate("UPDATE Step SET question= '$Step->question', answer= '$Step->answer',feedback = '$Step->feedback', stepType = '$Step->stepType', Exercise_idExercise = $Step->Exercise_idExercise WHERE idStep = $Step->idStep;");
    }
    
    //get all step
    public static function getAllStep(){
    //Prepare query
        $sql = "SELECT * FROM Step";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();
        
        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve rows
            $row = $results->fetch_array();
            
            //convert to objects
            $step = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $step;
        }
        return $resultsArray;
    }  
    
    //get step by id
    public static function getStepById($idStep){
        $sql = "SELECT * FROM Step WHERE idStep = $idStep;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $user = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $user;
        }
        return $resultsArray;
    }
    public static function getLastStep(){
        //Prepare query
        $sql = "SELECT * FROM Step ORDER BY idStep DESC LIMIT 1;";
        //query execute
        $con = self::getConnection();
        $results = $con->executeQuery($sql);
        $resultsArray = array();

        for($i = 0; $i < $results->num_rows ; $i++){
            //retrieve row
            $row = $results->fetch_array();
            
            //convert to objects
            $step = self::convertToObject($row);
            //add object to array
            
            $resultsArray[$i] = $step;
        }
        
        
        return $resultsArray;
    }
    // create Step object
    public static function convertToObject($row){
        return new Step(
            $row["idStep"],
            $row["question"],
            $row["answer"],
            $row["feedback"],
            $row["stepType"],
            $row["timestampLastUpdated"],
            $row["timestampCreated"],
            $row["Exercise_idExercise"]
        );
    }
}
?>
