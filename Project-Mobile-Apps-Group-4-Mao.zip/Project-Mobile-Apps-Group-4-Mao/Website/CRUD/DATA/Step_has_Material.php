<?php
class StepHasMaterial{
    public $Step_idStep;
    public $Material_idMaterial;
    public $timestampLastUpdated;
    public $timestampCreated;
    
    public function __construct($Step_idStep, $Material_idMaterial, $timestampLastUpdated, $timestampCreated){
        $this->Step_idStep = $Step_idStep;
        $this->Material_idMaterial = $Material_idMaterial;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
    }
}
?>
