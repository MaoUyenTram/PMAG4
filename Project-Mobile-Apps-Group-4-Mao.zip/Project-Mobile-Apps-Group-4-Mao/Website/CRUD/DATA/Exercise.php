<?php
class Exercise{
    public $idExercise;
    public $exercise_name;
    public $exercise_description;
    public $exercise_deadline;
    public $timestampLastUpdated;
    public $timestampCreated;
    public $Course_idCourse;

    public function __construct($idExercise, $exercise_name, $exercise_description, $exercise_deadline, $timestampLastUpdated, $timestampCreated, $Course_idCourse){
        $this->idExercise = $idExercise;
        $this->exercise_name = $exercise_name;
        $this->exercise_description = $exercise_description;
        $this->exercise_deadline = $exercise_deadline;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
        $this->Course_idCourse = $Course_idCourse;
    }
}

?>
