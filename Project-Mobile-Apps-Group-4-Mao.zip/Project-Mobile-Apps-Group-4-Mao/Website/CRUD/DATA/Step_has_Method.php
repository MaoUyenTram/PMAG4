<?php
class StepHasMethod{
    public $Step_idStep;
    public $Method_idMethod;
    public $timestampLastUpdated;
    public $timestampCreated;
    
    public function __construct($Step_idStep, $Method_idMethod, $timestampLastUpdated, $timestampCreated){
        $this->Step_idStep = $Step_idStep;
        $this->Method_idMethod = $Method_idMethod;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
    }
}
?>
