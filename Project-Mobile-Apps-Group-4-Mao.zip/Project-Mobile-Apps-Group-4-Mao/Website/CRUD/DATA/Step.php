<?php
class Step{
    public $idStep;
    public $question;
    public $answer;
    public $feedback;
    public $stepType;
    public $timestampLastUpdated;
    public $timestampCreated;
    public $Exercise_idExercise;

    public function __construct($idStep, $question, $answer, $feedback, $stepType, $timestampLastUpdated, $timestampCreated, $Exercise_idExercise){
        $this->idStep = $idStep;
        $this->question = $question;
        $this->answer = $answer;
        $this->feedback = $feedback;
        $this->stepType = $stepType;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
        $this->Exercise_idExercise = $Exercise_idExercise;
        
    }
}
?>
