<?php
class Course{
    public $idCourse;
    public $course_department;
    public $course_name;
    public $course_year;
    public $timestampLastUpdated;
    public $timestampCreated;

    public function __construct($idCourse, $course_department, $course_name, $course_year, $timestampLastUpdated, $timestampCreated){
        $this->idCourse = $idCourse;
        $this->course_department = $course_department;
        $this->course_name = $course_name;
        $this->course_year = $course_year;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
    }
}
?>
