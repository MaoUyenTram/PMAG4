<?php
class UserHasCourseView{
    public $idUser;
    public $user_name;
    public $idCourses;
    public $course_name;
    
    public function __construct($idUser, $user_name, $idCourse, $course_name){
        $this->User_idUser = $idUser;
        $this->user_name = $user_name;
        $this->Course_idCourse = $idCourse;
        $this->course_name = $course_name;
    }
}
?>