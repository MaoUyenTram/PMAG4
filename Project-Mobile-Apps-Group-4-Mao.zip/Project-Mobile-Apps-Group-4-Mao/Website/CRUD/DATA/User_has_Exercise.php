<?php
class UserHasExercise{
    public $User_idUser;
    public $Exercise_idExercise;
    public $passed;
    public $attempts;
    public $timestampSinceLastBan;
    public $timestampLastUpdated;
    public $timestampCreated;

    public function __construct($User_idUser, $Exercise_idExercise, $passed, $attempts, $timestampSinceLastBan, $timestampLastUpdated, $timestampCreated){
        $this->User_idUser = $User_idUser;
        $this->Exercise_idExercise = $Exercise_idExercise;
        $this->passed = $passed;
        $this->attempts = $attempts;
        $this->timestampSinceLastBan = $timestampSinceLastBan;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
    }
}
?>
