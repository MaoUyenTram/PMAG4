<?php
class Material{
    public $idMaterial;
    public $material_name;
    public $material_description;
    public $material_image;
    public $material_qualitative;
    public $timestampLastUpdated;
    public $timestampCreated;

    public function __construct($idMaterial, $material_name, $material_description, $material_image, $material_qualitative, $timestampLastUpdated, $timestampCreated){
        $this->idMaterial = $idMaterial;
        $this->material_name = $material_name;
        $this->material_description = $material_description;
        $this->material_image = $material_image; 
        $this->material_qualitative = $material_qualitative;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
        
    }
}
?>
