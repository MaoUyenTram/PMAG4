<?php
class UserHasCourse{
    public $idUser;
    public $idCourse;
    public $timestampSinceLastBan;
    public $timestampLastUpdated;
    public $timestampCreated;
    
    public function __construct($idUser, $idCourse, $timestampSinceLastBan, $timestampLastUpdated, $timestampCreated){
        $this->User_idUser = $idUser;
        $this->Course_idCourse = $idCourse;
        $this->timestampSinceLastBan = $timestampSinceLastBan;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
    }
}
?>
