<?php
class Method{
    public $idMethod;
    public $text;
    public $stepNumber;
    public $timestampLastUpdated;
    public $timestampCreated;

    public function __construct($idMethod, $text, $stepNumber, $timestampLastUpdated, $timestampCreated){
        $this->idMethod = $idMethod;
        $this->text = $text;
        $this->stepNumber = $stepNumber;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
        
    }
}
?>
