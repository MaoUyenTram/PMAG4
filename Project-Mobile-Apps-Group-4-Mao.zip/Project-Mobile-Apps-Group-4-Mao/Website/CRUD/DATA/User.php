<?php
class User{
    public $idUser;
    public $user_email;
    public $user_name;
    public $user_pass;
    public $user_active;
    public $user_type;
    public $timestampLastUpdated;
    public $timestampCreated;

    public function __construct($idUser, $user_email, $user_name, $user_pass, $user_active, $user_type, $timestampLastUpdated, $timestampCreated){
        $this->idUser = $idUser;
        $this->user_email = $user_email;
        $this->user_name = $user_name;
        $this->user_pass = $user_pass;
        $this->user_active = $user_active;
        $this->user_type = $user_type;
        $this->timestampLastUpdated = $timestampLastUpdated;
        $this->timestampCreated = $timestampCreated;
    }
}
?>
