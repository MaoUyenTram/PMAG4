<?php
session_start();
    
    //redirect function
    function redirect($page){
        header("Location:".$page);
    }

    //destroy and redirect user if not amdin
    if(!isset($_SESSION["admin"])){
        session_destroy();
        redirect("index.php");
    }

?>
 <!doctype html>
 <html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
        <link rel="stylesheet" href="css/footer.css">

        <title>PMAG4</title>
    </head>

    <body>
        <header class="banner">
            <?php
            include_once("scripts/menuadmin.php");
        ?>
        </header>
        <br>
        <main class="main container">
            <h1>Welkom,
                <?php echo $_SESSION["admin"];?>
            </h1>
            <br>
            <h4>
                Voeg een cursus toe
            </h4>
            <section class="row justify-content-center">
                <form role="form" class="form col-sm-6" action="scripts/voegtoe.php" method="POST">
                    <div class="form-group">
                        <label for="course_department">Cursus Richting: </label>
                        <select class="form-control" name="course_department" id="course_department">
                            <option value="Biomedische">Biomedische</option>
                            <option value="Voedingskunde">Voedingskunde</option>
                            <option value="Vroedkunde">Vroedkunde</option>
                            <option value="Verpleegkunde">Verpleegkunde</option>
                            <option value="Verpleegkunde(HBO5)">Verpleegkunde(HBO5)</option>
                            <option value="Pediatrie">Pediatrie</option>
                            <option value="Zorgmanagement">Zorgmanagement</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="course_name">Cursus Naam: </label>
                        <input class="form-control" type="text" name="course_name" placeholder="Name">
                    </div>
                    <div class="form-group">
                        <label for="course_year">Cursus Jaar: </label>
                        <select class="form-control" name="course_year" id="course_year">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-outline-success" value="Save" name="saveCourse">
                    </div>
                </form>
            </section>
        </main>
        <br>
        <footer role="footer" class="footer bg-dark text-center text-light">
            <p>PMAG 4 | &copy;
                <?php echo date("Y");?>
            </p>
        </footer>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <dy>
</html>